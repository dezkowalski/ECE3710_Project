import re


def main():
    inputFile = 'instrs.txt'
    outputFile = 'initialization.txt'
    # read from file (1 instr per line)
    instrs = open(inputFile, 'r')
    machineCode = open(outputFile, 'w')

    # write bits to text file (16 bits, then newline) (filename = initialization.txt)
    for count, line in enumerate(instrs):
        print("Instr {}: {}".format(count, line), end='')
        count += 1  # instruction number
        # parse to find instr, then switch to decide what to do with other parts
        currentInstr = re.split(" |, |\(|\)", line)
        instrBits = create_machine_code(currentInstr)
        # add machine code instruction to output file
        machineCode.write(instrBits + '\n')  # opcode[0:4] + rdest + opcode[4:8] + rsrc

    instrs.close()


def create_machine_code(currentInstr):

    # # read from file (1 instr per line)
    # instrs = open(inputFile, 'r')
    # machineCode = open(outputFile, 'w')
    #
    # # write bits to text file (16 bits, then newline) (filename = initialization.txt)
    # for count, line in enumerate(instrs):
    #     print("Instr {}: {}".format(count, line), end='')
    #     count += 1  # instruction number
    #     # parse to find instr, then switch to decide what to do with other parts
    #     currentInstr = re.split(" |, |\(|\)", line)

        # inside or outside of loop?? init values
        opcode = 0
        imm = 0
        rdest = 0
        rsrc = 0
        raddr = 0
        rdata = 0
        instrBits = ''

        # ADD INSTRS
        if currentInstr[0] == 'add':  # add Rsrc, Rdest
            opcode = "00000101"  # 0000 0101
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc  # 0000 Rdest 0101 Rsrc

        elif currentInstr[0] == 'addi':  # addi imm, Rdest
            opcode = "01010000"  # 0101 XXXX
            imm = int(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            immStr = sign_extend_imm(imm)

            instrBits = opcode[0:4] + rdest + immStr  # 0001 Rdest ImmHi ImmLo

        elif currentInstr[0] == 'addu':  # addu rsrc, rdest
            opcode = "00000110"  # 0000 0110
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc  # 0000 Rdest 0110 Rsrc

        elif currentInstr[0] == 'addui': # addui imm, rdest
            opcode = "01100000"  # 0110 XXXX
            imm = int(currentInstr[1])
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            immStr = sign_extend_imm(imm)

            instrBits = opcode[0:4] + rdest + immStr  # 0110 Rdest ImmHi ImmLo

        elif currentInstr[0] == 'addc': # addc rsrc, rdest
            opcode = "00000111"  # 0000 0111
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc  # 0000 Rdest 0111 Rsrc

        elif currentInstr[0] == 'addcu': # addcu rsrc, rdest
            opcode = "00000100"  # 0000 0100
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc  # 0000 rdest 0100 rsrc

        elif currentInstr[0] == 'addcui': # addcui imm, rdest
            opcode = "11010000"  # 1101 XXXX
            imm = int(currentInstr[1])
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            immStr = sign_extend_imm(imm)

            instrBits = opcode[0:4] + rdest + immStr  # 1101 rdest immhi immlo

        elif currentInstr[0] == 'addci':  # addci imm, rdest
            opcode = "01110000"  # 0111 XXXX
            imm = int(currentInstr[1])
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            immStr = sign_extend_imm(imm)

            instrBits = opcode[0:4] + rdest + immStr  # 0111 rdest immhi immlo

        # SUB INSTRS
        elif currentInstr[0] == 'sub': # sub rsrc, rdest
            opcode = "00001001"  # 0000 1001
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc  # 0000 rdest 1001 rsrc

        elif currentInstr[0] == 'subi':  # subi imm, rdest
            opcode = '10010000'  # 1001 XXXX
            imm = int(currentInstr[1])
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            immStr = sign_extend_imm(imm)

            instrBits = opcode[0:4] + rdest + immStr   # 1001 rdest immhi immlo

        # COMP INSTRS

        elif currentInstr[0] == 'cmp':  # cmp rsrc, rdest
            opcode = '00001011'     # 0000 1011
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc     # 0000 rdest 1011 rsrc

        elif currentInstr[0] == 'cmpi':  # cmpi imm, rdest
            opcode = '10110000'     # 1011 XXXX
            imm = int(currentInstr[1])
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            immStr = sign_extend_imm(imm)

            instrBits = opcode[0:4] + rdest + immStr        # 1011 rdest immhi immlo

        elif currentInstr[0] == 'cmpu':  # cmpu rsrc, rdest
            opcode = '00001101'  # 0000 1101
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc    # 0000 rdest 1101 rsrc

        elif currentInstr[0] == 'cmpui':  # cmpui imm, rdest
            opcode = '10100000'     # 1010 XXXX
            imm = int(currentInstr[1])
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            immStr = sign_extend_imm(imm)

            instrBits = opcode[0:4] + rdest + immStr        # 1010 rdest immhi immlo

        # LOGICAL INSTRS
        elif currentInstr[0] == 'and':  # and rsrc, rdest
            opcode = "00000001"  # 0000 0001
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc  # 0000 rdest 0001 rsrc

        elif currentInstr[0] == 'or':  # or rsrc, rdest
            opcode = "00000010"  # 0000 0010
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc  # 0000 rdest 0010 rsrc

        elif currentInstr[0] == 'xor':  # xor rsrc, rdest
            opcode = '00000011'  # 0000 0011
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc  # 0000 rdest 0011 rsrc

        elif currentInstr[0] == 'not': # not rdest
            opcode = "00001111"  # 0000 1111
            rdest = convert_reg_to_binary(currentInstr[1].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + '0000'    # 0000 rdest 1111 ????

        # SHIFT INSTRS

        elif currentInstr[0] == 'lsh':  # lsh ramount, rdest
            opcode = '00001000'  # 0000 1000
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc    # 0000 rdest 1000 rsrc

        elif currentInstr[0] == 'lshi':  # lshi imm, rdest
            opcode = '11110000'  # 1111 XXXX
            imm = int(currentInstr[1])
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            immStr = sign_extend_imm(imm)

            instrBits = opcode[0:4] + rdest + immStr  # 1111 rdest immhi immlo

        elif currentInstr[0] == 'rsh':  # rsh ramount, rdest
            opcode = '00001010'  # 0000 1010
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc    # 0000 rdest 1010 rsrc

        elif currentInstr[0] == 'rshi':  # rshi imm, rdest
            opcode = '11100000'  # 1110 XXXX
            imm = int(currentInstr[1])
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            immStr = sign_extend_imm(imm)

            instrBits = opcode[0:4] + rdest + immStr  # 1110 rdest immhi immlo

        elif currentInstr[0] == 'alsh':  # alsh ramount, rdest
            opcode = '00001100'  # 0000 1100
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc    # 0000 rdest 1100 rsrc

        elif currentInstr[0] == 'arsh':  # arsh ramount, rdest
            opcode = '00001110'  # 0000 1110
            rsrc = convert_reg_to_binary(currentInstr[1].strip())
            rdest = convert_reg_to_binary(currentInstr[2].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + rsrc    # 0000 rdest 1110 rsrc

        # OTHER INSTRS
        elif currentInstr[0] == 'nop':  # nop
            opcode = '00000000'  # 0000 000

            instrBits = opcode[0:4] + '0000' + opcode[4:8] + '0000'  # 0000 ???? 0000 ????

        elif currentInstr[0] == 'ld':  # ld rdest(rdata), rsrc(raddr)
            opcode = "00010000"  # 0001 XXXX
            raddr = convert_reg_to_binary(currentInstr[2].strip())  # address
            rdata = convert_reg_to_binary(currentInstr[1].strip()) # data

            instrBits = opcode[0:4] + rdata + opcode[4:8] + raddr  # 0001 rdata 0000 raddr

        elif currentInstr[0] == 'sw':  # sw rsrc(rdata), rdest(raddr)
            opcode = "00100000"  # 0010 XXXX
            raddr = convert_reg_to_binary(currentInstr[2].strip()) # address
            rdata = convert_reg_to_binary(currentInstr[1].strip()) # data

            instrBits = opcode[0:4] + rdata + opcode[4:8] + raddr  # 0010 rdata 0000 raddr

        elif currentInstr[0] == "jmp":  # jmp rdest
            opcode = '00110000'     # 0011 XXXX
            rdest = convert_reg_to_binary(currentInstr[1].strip())

            instrBits = opcode[0:4] + rdest + opcode[4:8] + '0000'  # 0011 rdest XXXX XXXX

        elif currentInstr[0] == "stop":  # stop
            opcode = '01000000'     # 0100 0000

            instrBits = opcode[0:4] + '0000' + opcode[4:8] + '0000' # 0100 xxxx 0000 xxxx

        print("\n opcode: {}, rdest: {}, rsrc: {}, imm: {}".format(opcode, rdest, rsrc, imm))
        return instrBits


    #     # add machine code instruction to output file
    #     machineCode.write(instrBits + '\n')  # opcode[0:4] + rdest + opcode[4:8] + rsrc
    #
    # instrs.close()


# this function takes a string in the form 'rx' where x is 0-15,
# and returns a string of that register in binary
def convert_reg_to_binary(reg):
    regVal = -1
    if(reg == 'r0'):
        regVal = '0000'  # 0
    elif(reg == 'r1'):
        regVal = '0001'  # 1
    elif (reg == 'r2'):
        regVal = '0010'  # 2
    elif (reg == 'r3'):
        regVal = '0011'  # 3
    elif (reg == 'r4'):
        regVal = '0100'  # 4
    elif (reg == 'r5'):
        regVal = '0101'  # 5
    elif (reg == 'r6'):
        regVal = '0110'  # 6
    elif (reg == 'r7'):
        regVal = '0111'  # 7
    elif (reg == 'r8'):
        regVal = '1000'  # 8
    elif (reg == 'r9'):
        regVal = '1001'  # 9
    elif (reg == 'r10'):
        regVal = '1010'  # 10
    elif (reg == 'r11'):
        regVal = '1011'  # 11
    elif (reg == 'r12'):
        regVal = '1100'  # 12
    elif (reg == 'r13'):
        regVal = '1101'  # 13
    elif (reg == 'r14'):
        regVal = '1110'  # 14
    elif (reg == 'r15'):
        regVal = '1111'  # 15

    return (regVal)


# takes in binary number. Extends to 8 bits.
# removes '0b' prefix
# returns string of sign extended binary
def sign_extend_imm(imm):

    temp_str = str(imm)
    if temp_str[0] =='-':
        immStr = str(bin(imm % (1 << 8)))
        immStr = immStr[2:]  # get rid of '0b' prefix
    else:
        print("HEY!!!! :", imm)
        immStr = format(imm, '08b')

    return immStr


if __name__ == "__main__":
    main()