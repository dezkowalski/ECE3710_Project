from Assembler import *

# ------- ADD TESTS -------
# regular add registers
def test_add():
    # 0000 Rdest 0101 Rsrc
    input_instr = re.split(" |, |\(|\)", 'add r3, r10')
    output = create_machine_code(input_instr)

    assert output == '0000101001010011'  # 0000 1010 0101 0011


# signed add imm, use negative
def test_addi():
    # 0001 Rdest ImmHi ImmLo
    input_instr = re.split(" |, |\(|\)", 'addi -30, r13')
    output = create_machine_code(input_instr)

    assert output == '0101110111100010'  # 0101 1101 1110 0010


# add registers unsigned
def test_addu():
    # 0000 Rdest 0110 Rsrc
    input_instr = re.split(" |, |\(|\)", 'addu r1, r9')
    output = create_machine_code(input_instr)

    assert output == '0000100101100001'  # 0000 1001 0110 0001


# unsigned add imm, use positive
def test_addui():
    # 0110 Rdest ImmHi ImmLo
    input_instr = re.split(" |, |\(|\)", 'addui 112, r7')
    output = create_machine_code(input_instr)

    assert output == '0110011101110000'  # 0110 0111 0111 0000


# add registers
def test_addc():
    # 0000 Rdest 0111 Rsrc
    input_instr = re.split(" |, |\(|\)", 'addc r11, r2')
    output = create_machine_code(input_instr)

    assert output == '0000001001111011'  # 0000 0010 0111 1011


# add registers unsigned
def test_addcu():
    # 0000 rdest 0100 rsrc
    input_instr = re.split(" |, |\(|\)", 'addcu r7, r5')
    output = create_machine_code(input_instr)

    assert output == '0000010101000111'  # 0000 0101 0100 0111


# unsigned add imm, use positive
def test_addcui():
    # 1101 rdest immhi immlo
    input_instr = re.split(" |, |\(|\)", 'addcui 107, r4')
    output = create_machine_code(input_instr)

    assert output == '1101010001101011'  # 1101 0100 0110 1011


# unsigned add imm, use positive
def test_addci():
    # 0111 rdest immhi immlo
    input_instr = re.split(" |, |\(|\)", 'addci 32, r5')
    output = create_machine_code(input_instr)

    assert output == '0111010100100000'  # 0111 0101 0010 0000


# ------- SUB TESTS -------
# regular sub registers
def test_sub():
    # 0000 rdest 1001 rsrc
    input_instr = re.split(" |, |\(|\)", 'sub r12, r1')
    output = create_machine_code(input_instr)

    assert output == '0000000110011100'  # 0000 0001 1001 1100


# signed sub imm, use negative
def test_subi():
    # 1001 rdest immhi immlo
    input_instr = re.split(" |, |\(|\)", 'subi -46, r10')
    output = create_machine_code(input_instr)

    assert output == '1001101011010010'  # 1001 1010 1101 0010


# ------- COMP TESTS -------
# regular cmp registers
def test_cmp():
    # 0000 rdest 1011 rsrc
    input_instr = re.split(" |, |\(|\)", 'cmp r3, r8')
    output = create_machine_code(input_instr)

    assert output == '0000100010110011'  # 0000 1000 1011 0011


# signed cmp imm, use negative
def test_cmpi():
    # 1011 rdest immhi immlo
    input_instr = re.split(" |, |\(|\)", 'cmpi -107, r10')
    output = create_machine_code(input_instr)

    assert output == '1011101010010101'  # 1011 1010 1001 0101

# unsigned compare
def test_cmpu():
    # 0000 rdest 1101 rsrc
    input_instr = re.split(" |, |\(|\)", 'cmpu r0, r5')
    output = create_machine_code(input_instr)

    assert output == '0000010111010000'  # 0000 0101 1101 0000


# unsigned cmp imm, use pos
def test_cmpui():
    # 1010 rdest immhi immlo
    input_instr = re.split(" |, |\(|\)", 'cmpui 200, r6')
    output = create_machine_code(input_instr)

    assert output == '1010011011001000'  # 1010 0110 1100 1000


# ------- LOGICAL TESTS -------
# and registers
def test_and():
    # 0000 rdest 0001 rsrc
    input_instr = re.split(" |, |\(|\)", 'and r3, r3')
    output = create_machine_code(input_instr)

    assert output == '0000001100010011'  # 0000 0011 0001 0011


# or registers
def test_or():
    # 0000 rdest 0010 rsrc
    input_instr = re.split(" |, |\(|\)", 'or r14, r9')
    output = create_machine_code(input_instr)

    assert output == '0000100100101110'  # 0000 1001 0010 1110


# xor registers
def test_xor():
    # 0000 rdest 0011 rsrc
    input_instr = re.split(" |, |\(|\)", 'xor r15, r1')
    output = create_machine_code(input_instr)

    assert output == '0000000100111111'  # 0000 0001 0011 1111


# not registers
def test_not():
    # 0000 rdest 1111 ????
    input_instr = re.split(" |, |\(|\)", 'not r2')
    output = create_machine_code(input_instr)

    assert output == '0000001011110000'  # 0000 0010 1111 xxxx


# ------- SHIFT TESTS -------
# regular left shift registers
def test_lsh():
    # 0000 rdest 1000 rsrc
    input_instr = re.split(" |, |\(|\)", 'lsh r4, r9')
    output = create_machine_code(input_instr)

    assert output == '0000100110000100'  # 0000 1001 1000 0100


# signed left shift imm, use negative
def test_lshi():
    # 1111 rdest immhi immlo
    input_instr = re.split(" |, |\(|\)", 'lshi -54, r11')
    output = create_machine_code(input_instr)

    assert output == '1111101111001010'  # 1111 1011 1100 1010


# regular right shift registers
def test_rsh():
    # 0000 rdest 1010 rsrc
    input_instr = re.split(" |, |\(|\)", 'rsh r5, r11')
    output = create_machine_code(input_instr)

    assert output == '0000101110100101'  # 0000 1011 1010 0101


# signed right shift imm, use negative
def test_rshi():
    # 1110 rdest immhi immlo
    input_instr = re.split(" |, |\(|\)", 'rshi -92, r3')
    output = create_machine_code(input_instr)

    assert output == '1110001110100100'  # 1110 0011 1010 0100


# regular arith left shift registers
def test_alsh():
    # 0000 rdest 1100 rsrc
    input_instr = re.split(" |, |\(|\)", 'alsh r2, r10')
    output = create_machine_code(input_instr)

    assert output == '0000101011000010'  # 0000 1010 1100 0010


# regular arith right shift registers
def test_arsh():
    # 0000 rdest 1110 rsrc
    input_instr = re.split(" |, |\(|\)", 'arsh r3, r12')
    output = create_machine_code(input_instr)

    assert output == '0000110011100011'  # 0000 1100 1110 0011


# ------- OTHER TESTS -------
# no oper.
def test_nop():
    # 0000 xxxx 0000 xxxx
    input_instr = re.split(" |, |\(|\)", 'nop')
    output = create_machine_code(input_instr)

    assert output == '0000000000000000'  # 0000 0000 0000 0000


# load
def test_ld():
    # 0001 rdata 0000 raddr
    input_instr = re.split(" |, |\(|\)", 'ld r7, r13')  # ld rdest(rdata), rsrc(raddr)
    output = create_machine_code(input_instr)

    assert output == '0001011100001101'  # 0001 0111 0000 1101


# store
def test_sw():
    # 0010 rdata 0000 raddr
    input_instr = re.split(" |, |\(|\)", 'sw r7, r13')  # sw rsrc(rdata), rdest(raddr)
    output = create_machine_code(input_instr)

    assert output == '0010011100001101'  # 0010 0111 0000 1101


# jump instr
def test_jmp():
    # 0011 rdest XXXX XXXX
    input_instr = re.split(" |, |\(|\)", 'jmp r6')
    output = create_machine_code(input_instr)

    assert output == '0011011000000000'  # 0011 0110 0000 0000


# stop / hold
def test_stop():
    # 0100 xxxx 0000 xxxx
    input_instr = re.split(" |, |\(|\)", 'stop')
    output = create_machine_code(input_instr)

    assert output == '0100000000000000'  # 0100 0000 0000 0000